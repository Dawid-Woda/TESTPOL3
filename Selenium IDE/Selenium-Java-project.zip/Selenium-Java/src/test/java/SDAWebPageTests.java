import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertEquals;

public class SDAWebPageTests {
    private WebDriver driver;

    @Before
    public void setUp() {
        driver = new ChromeDriver();  // inicjalizacja ChromeDrivera
    }

    @Test
    public void TestPrintSDAcademyPageTitleOnConsole() {
        driver.get("https://sdacademy.dev"); // uruchomienie strony https://sdacademy.dev

        assertEquals(driver.getTitle(), "Software Development Academy - Learn IT from Scratch"); // sprawdzenie czy aktualny tytuł strony jest zgodny z oczekiwanym
    }

    @After
    public void tearDown() {
        driver.close(); // zamknięcie przeglądarki
    }
}
